from django.apps import AppConfig


class KartyConfig(AppConfig):
    name = 'karty'
