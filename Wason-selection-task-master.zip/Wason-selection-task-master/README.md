<h1> Wason selection task </h1>

The Wason selection task (or four-card problem) is a logic puzzle devised by Peter Cathcart.
It is one of the most famous tasks in the study of deductive reasoning. For more see: https://en.wikipedia.org/wiki/Wason_selection_task

<h2> Features </h2>
Project is implemented using *Django* framework for backend and *HTML5* & *CSS* and *JS* for frontend. The researcher can configure many things using admin panel. The one can choose i.e.
duration of particular experiment phase, add new cards. It is also possible to generate raports from users sessions. Raports are generated to csv, and contains of many details of user session.

**Usage of *web workes* is one of the things that are worth the attention.**


